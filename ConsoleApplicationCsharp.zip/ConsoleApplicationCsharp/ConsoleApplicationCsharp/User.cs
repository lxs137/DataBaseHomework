﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// User 的摘要说明
/// </summary>
public class User
{
    private String userName;
    private List<int> wrongQuestions;
    private Test myTest;
    public User(String userName)
    {
        this.userName = userName; 
        wrongQuestions=new List<int>();
        myTest = new Test();
    }
    public Test getTest()
    {
        return this.myTest;
    }
    public void startTestSimulation(String tableName)
    {
        myTest.initTestSimulation(tableName);
    }
    public void startTestWrong(String tableName)
    {
        myTest.initTestWrong(tableName,this.userName);
    }
    public void startTestAllOrder(String tableName)
    {
        myTest.initTestAllOrder(tableName);
    }
    public void startTestAllRand(String tableName)
    {
        myTest.initTestAllRand(tableName);
    }
    public void storeWrongQuestion(String testName)
    {
        String wrongStr = "";
        foreach(int temp in wrongQuestions)
        {
            wrongStr+=temp+",";
        }
        DataBaseConnectHelper dataBaseConnect = new DataBaseConnectHelper();
        dataBaseConnect.addWrongQuestionIntoDataBase(this.userName, testName, wrongStr);
    }
    public void increaseWrongQuestion(int[] wrongID)
    {
        for(int i=0;i<wrongID.Length;i++)
        {
            if (!wrongQuestions.Contains(wrongID[i])) wrongQuestions.Add(wrongID[i]);
        }
    }
}