﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

public class Test
{
    private QuestionDataBase questionData;
    private String tableName;
    public Test()
    {

    }
    public QuestionDataBase getQuestionDataInstance()
    {
        return this.questionData;
    }
    public void initTestSimulation(String tableName)
    {
        this.tableName = tableName;
        int questionTotalNum=1229;
        int size=100;
        questionData = new QuestionDataBase();
        List<int> questionID = new List<int>();
        int tempID;
        Random rand=new Random();
        while(questionID.Count<size)
        {
            tempID = rand.Next(1,questionTotalNum);
            if (!questionID.Contains(tempID)) questionID.Add(tempID);
        }
        questionData.initBaseFromSQLBase(new DataBaseConnectHelper(), this.tableName, questionID.ToArray());
    }
    public void initTestWrong(String tableName,String userName)
    {
        this.tableName = tableName;
        questionData = new QuestionDataBase();
        DataBaseConnectHelper dataBaseConnect = new DataBaseConnectHelper();
        String[] wrongStr=new Regex(@",").Split(dataBaseConnect.getWrongQuestionFromDataBase(userName, this.tableName));
        List<int> wrongID=new List<int>();
        foreach(String str in wrongStr)
        {
            wrongID.Add(int.Parse(str));
        }
        questionData.initBaseFromSQLBase(new DataBaseConnectHelper(),this.tableName,wrongID.ToArray());
    }
    public void initTestAllOrder(String tableName)
    {
        this.tableName = tableName;
        int questionTotalNum = 1229;
        questionData = new QuestionDataBase();
        List<int> questionID = new List<int>();
        int i = 1;
        while(i<questionTotalNum)
        {
            questionID.Add(i);
            i++;
        }
        questionData.initBaseFromSQLBase(new DataBaseConnectHelper(), this.tableName, questionID.ToArray());
    }
    public void initTestAllRand(String tableName)
    {
        this.tableName = tableName;
        int questionTotalNum = 1229;
        questionData = new QuestionDataBase();
        List<int> questionIDOrder = new List<int>();
        int i = 1;
        while (i < questionTotalNum)
        {
            questionIDOrder.Add(i);
            i++;
        }
        List<int> questionIDRand = new List<int>();
        int randID;
        Random rand = new Random();
        while(questionIDRand.Count<questionTotalNum-1)
        {
            randID = rand.Next(0, questionIDOrder.Count);
            questionIDRand.Add(questionIDOrder[randID]);
            questionIDOrder.RemoveAt(randID);
        }
        questionData.initBaseFromSQLBase(new DataBaseConnectHelper(), this.tableName, questionIDRand.ToArray());
    }
}
