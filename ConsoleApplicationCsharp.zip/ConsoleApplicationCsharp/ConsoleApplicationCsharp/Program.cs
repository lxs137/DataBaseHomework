﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplicationCsharp
{
    class Program
    {
        static void Main(string[] args)
        {
            WebConnectHelper webConnect = new WebConnectHelper();
            String strConnect = "";
            String strShow = ";";
            while (!webConnect.setConnection())
            {
               strShow = "Fall";
            }
            QuestionDataBase questionData = new QuestionDataBase();
            questionData.initBaseFromWeb(webConnect);
            questionData.loadDataIntoSQLBase();
            strShow = strConnect;
            strConnect += questionData.getQuestion(2).getID() + "\n";
            strConnect += questionData.getQuestion(2).getQuestion() + "\n";
            strConnect += questionData.getQuestion(2).getID() + "\n";
            strConnect += questionData.getQuestion(2).getItem(1) + "\n";
            strConnect += questionData.getQuestion(2).getItem(2) + "\n";
            strConnect += questionData.getQuestion(2).getItem(3) + "\n";
            strConnect += questionData.getQuestion(2).getItem(4) + "\n";
            strConnect += questionData.getQuestion(2).getExplains() + "\n";
            strConnect += questionData.getQuestion(2).getAnswer() + "\n";
            strConnect += questionData.getQuestion(2).getUrl() + "\n";

            strShow=strConnect;
        }

/*       static void Main(string[] args)
        {
            StreamReader stream = new StreamReader(@"E:\\test.txt");
            stream.ReadLine();
            Console.WriteLine(new Regex(@"\s""error_code"":\s0").IsMatch(stream.ReadLine()));
            stream.ReadLine();
            stream.ReadLine();
            String[] str = new Regex(@"},").Split(stream.ReadToEnd());
            int id;
            String questionContent;
            int answer;
            String[] items={"","","",""};
            String explains;
            String url;
            foreach(String strItem in str)
            {
                StringReader strReader = new StringReader(strItem);
               strReader.ReadLine();
               String[] questionStr = new Regex(@",").Split(strReader.ReadToEnd());
               String[] questionComponent={"","","","","","","","",""};
                int j=0;
                while (j < questionStr.Length)
                {
                    if (j == 0)
                    {
                        questionComponent[j] = new Regex(@"\d+").Match(questionStr[j]).ToString();
                    }
                    else
                    {
                        questionComponent[j] = new Regex(@"\s+""\w+"":\s""").Replace(questionStr[j], "");
                        questionComponent[j] = new Regex(@"""\s*").Replace(questionComponent[j], "");
                    } 
                    j++;
                }
                id = int.Parse(questionComponent[0]);
                questionContent = questionComponent[1];
                answer = int.Parse(questionComponent[2]);
                items[0] = questionComponent[3];
                items[1] = questionComponent[4];
                items[2] = questionComponent[5];
                items[3] = questionComponent[6];
                explains = questionComponent[7];
                url = questionComponent[8];
                Question question = new Question(id, questionContent, answer, items, explains, url);
                Console.WriteLine(question.getID());
                Console.WriteLine(question.getQuestion());
                Console.WriteLine(question.getAnswer());
                Console.WriteLine(question.getItem(0));
                Console.WriteLine(question.getItem(1));
                Console.WriteLine(question.getItem(2));
                Console.WriteLine(question.getItem(3));
                Console.WriteLine(question.getExplains());
                Console.WriteLine(question.getUrl());
            }
          Console.ReadLine();
        }
  
     static void Main(string[] args)
        {
            DataBaseConnectHelper dataBaseConnect = new DataBaseConnectHelper();
            String[] items = { "sad", "432", "123", "123" };
            dataBaseConnect.insertDataBase(new Question(15,"asd",3,items,"fg","http:\\"));
        }
  
        static void Main(string[] args)
        {
            User lxs = new User("123");
            lxs.startTestWrong("c1_1");
            QuestionDataBase questionData = lxs.getTest().getQuestionDataInstance();
            int size = questionData.getSize(),i=1;
            while(i<=size)
            {
                Question temp = questionData.getQuestion(i);
                Console.WriteLine(temp.getID());
                Console.WriteLine(temp.getQuestion());
                Console.WriteLine(temp.getItem(1));
                Console.WriteLine(temp.getItem(2));
                Console.WriteLine(temp.getItem(3));
                Console.WriteLine(temp.getItem(4));
                Console.WriteLine(temp.getAnswer());
                Console.WriteLine(temp.getExplains());
                Console.WriteLine(temp.getUrl());
                i++;
            }
            Console.ReadLine();
        }*/
    }
  
}
