﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// DataBaseConnectHelper 的摘要说明
/// </summary>
public class DataBaseConnectHelper : ConnectHelper
{
    SqlConnection connection;
    public DataBaseConnectHelper()
    {
        connection = new SqlConnection();
        connection.ConnectionString = "Data Source=LXS-PC\\SQLEXPRESS;initial catalog=Questions;Integrated Security=true";
        connection.Open();
    }

    public void insertQuestionInDataBase(Question question, String tableName)
    {
        try
        {
            SqlCommand cmd1 = connection.CreateCommand();
            cmd1.CommandText = "INSERT INTO " + tableName + " (id,question,answer,item1,item2,item3,item4,explains,url) VALUES (@id,@question,@answer,@item1,@item2,@item3,@item4,@explains,@url)";
            SqlParameter[] parameter = new SqlParameter[]
            {
                new SqlParameter("@id",SqlDbType.Int),
                new SqlParameter("@question",SqlDbType.Text),
                new SqlParameter("@answer",SqlDbType.Int),
                new SqlParameter("@item1",SqlDbType.Text),
                new SqlParameter("@item2",SqlDbType.Text),
                new SqlParameter("@item3",SqlDbType.Text),
                new SqlParameter("@item4",SqlDbType.Text),
                new SqlParameter("@explains",SqlDbType.Text),
                new SqlParameter("@url",SqlDbType.VarChar,200)
            };
            parameter[0].Value = question.getID();
            parameter[1].Value = question.getQuestion();
            parameter[2].Value = question.getAnswer();
            parameter[3].Value = question.getItem(1);
            parameter[4].Value = question.getItem(2);
            parameter[5].Value = question.getItem(3);
            parameter[6].Value = question.getItem(4);
            parameter[7].Value = question.getExplains();
            parameter[8].Value = question.getUrl();
            for (int i = 0; i < parameter.Length; i++)
            {
                cmd1.Parameters.Add(parameter[i]);
            }
            cmd1.ExecuteNonQuery();
        }
        catch (Exception e)
        {
        }
    }
    public Question getQuestionFromDataBase(int id, String tableName)
    {
        int questionId = id;
        String questionText = "";
        int questionAnswer = -1;
        String[] questionItem = new String[4];
        String questionExplains = "";
        String questionurl = "";
        try
        {
            tableName = tableName.Substring(0, 4) + "Questions";
            SqlCommand cmd1 = connection.CreateCommand();
            DataSet dataSet = new DataSet();
            cmd1.CommandText = "SELECT * FROM " + tableName + " WHERE id=" + id;
            SqlDataReader dataReader = cmd1.ExecuteReader();
            if (dataReader.Read())
            {
                questionText = dataReader.GetString(dataReader.GetOrdinal("question")).ToString();
                questionAnswer = int.Parse(dataReader.GetByte(dataReader.GetOrdinal("answer")).ToString());
                questionItem[0] = dataReader.GetString(dataReader.GetOrdinal("item1")).ToString();
                questionItem[1] = dataReader.GetString(dataReader.GetOrdinal("item2")).ToString();
                questionItem[2] = dataReader.GetString(dataReader.GetOrdinal("item3")).ToString();
                questionItem[3] = dataReader.GetString(dataReader.GetOrdinal("item4")).ToString();
                questionExplains = dataReader.GetString(dataReader.GetOrdinal("explains")).ToString();
                questionurl = dataReader.GetString(dataReader.GetOrdinal("url")).ToString();
            }
            dataReader.Close();
        }
        catch (Exception e)
        {
        }
        return new Question(questionId, questionText, questionAnswer, questionItem, questionExplains, questionurl);
    }
    public String getWrongQuestionFromDataBase(String userName, String testName)
    {
        SqlCommand cmd1 = connection.CreateCommand();
        DataSet dataSet = new DataSet();
        cmd1.CommandText = "SELECT wrongid_" + testName + " FROM Users WHERE username=" + userName;
        SqlDataReader dataReader = cmd1.ExecuteReader();
        if (dataReader.Read())
            return dataReader.GetString(dataReader.GetOrdinal("wrongid_" + testName)).ToString();
        else return "";
    }
    public void addWrongQuestionIntoDataBase(String userName,String testName,String questions)
    {
        try
        {
            SqlCommand cmd1 = connection.CreateCommand();
            cmd1.CommandText = "UPDATE Users SET wrongid_"+testName+"=\'"+questions+"\' WHERE username=\'"+userName+"\'";
            cmd1.ExecuteNonQuery();
        }
        catch(Exception e)
        {
        }
    }
    public void addNewUser(String userName,String password)
    {
        try
        {
            SqlCommand cmd1 = connection.CreateCommand();
            cmd1.CommandText = "INSERT INTO Users (username,password,wrongid_c1_1,wrongid_c1_4) VALUES (@username,@password,@wrongid_c1_1,@wrongid_c1_4)";
            SqlParameter[] parameter = new SqlParameter[]
            {
                new SqlParameter("@username",SqlDbType.VarChar,20),
                new SqlParameter("@password",SqlDbType.VarChar,20),
                new SqlParameter("@wrongid_c1_1",SqlDbType.NText),
                new SqlParameter("@wrongid_c1_4",SqlDbType.NText)
            };
            parameter[0].Value = userName;
            parameter[1].Value = password;
            parameter[2].Value = "";
            parameter[3].Value = "";
            for (int i = 0; i < parameter.Length; i++)
            {
                cmd1.Parameters.Add(parameter[i]);
            }
            cmd1.ExecuteNonQuery();
        }
        catch (Exception e)
        {
        }
    }
    public Boolean checkUser(String userName,String password)
    {
        SqlCommand cmd1 = connection.CreateCommand();
        cmd1.CommandText = "SELECT username,password FROM Users WHERE username=\'" + userName + "\' AND password=\'" + password + "\'";
        if (cmd1.ExecuteScalar() !=null) return true;
        else return false;
    }

}