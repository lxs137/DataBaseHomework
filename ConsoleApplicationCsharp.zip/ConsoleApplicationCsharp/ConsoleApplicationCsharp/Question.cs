﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Question 的摘要说明
/// </summary>
public class Question
{
    private int id;
    private String question;
    private int answer;
    private String[] items = { "", "", "", "" };
    private String explains;
    private String url;

    public Question()
    {
        this.id = -1;
        this.question = null;
        this.answer = -1;
        this.explains = null;
        this.url = null;
    }

    public Question(int Nid, String Nquestion, int Nanswer, String[] Nitems, String Nexplains, String Nurl)
    {
        this.id = Nid;
        this.question = Nquestion;
        this.answer = Nanswer;
        this.explains = Nexplains;
        this.url = Nurl;
        int i = 0;
        while (i < Nitems.Length)
        {
            this.items[i] = Nitems[i];
            i++;
        }
    }
    public Boolean checkAnswer(int answer)
    {
        if (this.answer == answer) return true;
        else return false;
    }
    public int getID()
    {
        return this.id;
    }
    public String getQuestion()
    {
        return this.question;
    }
    public int getAnswer()
    {
        return this.answer;
    }
    public String getExplains()
    {
        return this.explains;
    }
    public String getUrl()
    {
        return this.url;
    }
    public String getItem(int index)
    {
        index = index - 1;
        if (index < 0 || index >= this.items.Length) return null;
        else return this.items[index];
    }
}