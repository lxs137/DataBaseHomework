﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;

/// <summary>
/// QuestionDataBase 的摘要说明
/// </summary>
public class QuestionDataBase
{
    private List<Question> questions;
    public QuestionDataBase()
    {
        questions = new List<Question>();
    }
    public void addQuestion(Question question)
    {
        questions.Add(question);
    }
    public Question getQuestion(int index)
    {
        index = index - 1;
        return questions[index];
    }
    public int getSize()
    {
        return questions.Count;
    }
    public void initBaseFromWeb(WebConnectHelper webConnect)
    {
        int i = 0;
        List<Question> allQuestions = webConnect.parseQuestions();
        while (i < 100)
        {
            questions.Add(allQuestions[i]);
            i++;
        }
    }
    public void initBaseFromSQLBase(DataBaseConnectHelper dataBaseConnect,String tableName,int[] questionID)
    {
        for (int i = 0; i < questionID.Length; i++)
        {
            questions.Add(dataBaseConnect.getQuestionFromDataBase(questionID[i],tableName));
        }
    }
    public void loadDataIntoSQLBase()
    {
        DataBaseConnectHelper insertData = new DataBaseConnectHelper();
        int i = 0;
        foreach (Question question in questions)
        {
            insertData.insertQuestionInDataBase(question, "c1_4Questions");
            i++;
        }
    }
}