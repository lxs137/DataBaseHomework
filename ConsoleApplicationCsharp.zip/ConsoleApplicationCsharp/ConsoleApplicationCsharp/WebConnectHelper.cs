﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;

/// <summary>
/// WebConnectHelper 的摘要说明
/// </summary>
public class WebConnectHelper : ConnectHelper
{
    private System.Net.HttpWebRequest request;
    private HttpWebResponse response;

    public WebConnectHelper()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }

    public Boolean setConnection()
    {
        String url = "http://apis.baidu.com/bbtapi/jztk/jztk_query";
        String param = "subject=4&model=c1&testType=rand";
        String strURL = url + '?' + param;
        String apiKey = "ce03e5cb2bad95fb9e1c7f70eff0d351";
        request = (System.Net.HttpWebRequest)WebRequest.Create(strURL);
        request.Method = "GET";
        request.Headers.Add("apikey", apiKey);
        try
        {
            response = (System.Net.HttpWebResponse)request.GetResponse();
            return true;
        }
        catch (System.Net.WebException ex)
        {
            return false;
        }
    }


    public String readData()
    {
        System.IO.Stream stream;
        stream = response.GetResponseStream();
        StreamReader streamReader = new StreamReader(stream, Encoding.UTF8);
        String strSingleLine = "";
        String result = "";
        while ((strSingleLine = streamReader.ReadLine()) != null)
        {
            result += strSingleLine + "\r\n";
        }
        return result;
    }

    public List<Question> parseQuestions()
    {
        List<Question> questions = new List<Question>();
        StringReader stream = new StringReader(readData());
        stream.ReadLine();
        stream.ReadLine();
        if (!new Regex(@"\s""error_code"":\s0").IsMatch(stream.ReadLine())) return null;
        stream.ReadLine();
        stream.ReadLine();
        String[] str = new Regex(@"},").Split(stream.ReadToEnd());
        int id;
        String questionContent;
        int answer = -1;
        String[] items = { "", "", "", "" };
        String explains;
        String url;
        foreach (String strItem in str)
        {
            StringReader strReader = new StringReader(strItem);
            strReader.ReadLine();
            String[] questionStr = new Regex(@",\r\n").Split(strReader.ReadToEnd());
            String[] questionComponent = { "", "", "", "", "", "", "", "", "" };
            int j = 0;
            while (j < 9)
            {
                if (j == 0)
                {
                    questionComponent[j] = new Regex(@"\d+").Match(questionStr[j]).ToString();
                }
                else
                {
                    questionComponent[j] = new Regex(@"\s+""\w+"":\s""").Replace(questionStr[j], "");
                    questionComponent[j] = new Regex(@"""\s*").Replace(questionComponent[j], "");
                }
                j++;
            }
            id = int.Parse(questionComponent[0]);
            questionContent = questionComponent[1];
            try
            {
                answer = int.Parse(questionComponent[2]);
            }
            catch (Exception ee)
            {
                Console.WriteLine(questionComponent[2]);
            }
            items[0] = questionComponent[3];
            items[1] = questionComponent[4];
            items[2] = questionComponent[5];
            items[3] = questionComponent[6];
            explains = questionComponent[7];
            url = questionComponent[8];
            questions.Add(new Question(id, questionContent, answer, items, explains, url));
        }
        return questions;
    }
}